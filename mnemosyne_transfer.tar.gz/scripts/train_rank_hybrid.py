from __future__ import annotations

import argparse
import json
import math
import os
import platform
import random
import subprocess
import sys
import time
import uuid
from collections import defaultdict
from pathlib import Path

import joblib
import numpy as np
import torch
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from transformers import AutoModel, AutoTokenizer

try:
    from run_output_manager import compute_file_hash, prepare_output_directory, build_training_manifest
except ModuleNotFoundError as exc:
    # Only fallback to package import if run_output_manager itself is missing.
    # Re-raise if the error is from an internal import within run_output_manager.
    if exc.name == 'run_output_manager':
        from .run_output_manager import compute_file_hash, prepare_output_directory, build_training_manifest
    else:
        raise

DEFAULT_FEATURE_DIR = Path("C:/Users/xiaoyang/memory_dataset/features_v1")
DEFAULT_E5_MODEL = "intfloat/multilingual-e5-small"


def get_git_sha() -> str | None:
    """Get current git SHA, or None if not in a git repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return None


def set_seed(seed: int) -> None:
    """Set random seeds for Python, NumPy, and PyTorch."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def read_jsonl(path: Path) -> list[dict]:
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f]


def public_rows(rows: list[dict]) -> list[dict]:
    return [row for row in rows if row.get("dataset") == "public"]


def grouped(rows: list[dict]) -> dict[str, list[int]]:
    out: dict[str, list[int]] = defaultdict(list)
    for i, row in enumerate(rows):
        out[row["pair_id"].rsplit("::", 1)[0]].append(i)
    return out


def ranking_metrics(rows: list[dict], scores: np.ndarray) -> dict:
    groups: dict[str, list[tuple[float, int]]] = defaultdict(list)
    for row, score in zip(rows, scores):
        groups[row["pair_id"].rsplit("::", 1)[0]].append((float(score), int(row["label"])))
    values = {key: [] for key in ("Recall@1", "Recall@5", "Recall@10", "MRR", "NDCG@5", "NDCG@10")}
    for candidates in groups.values():
        ranked = sorted(candidates, key=lambda x: x[0], reverse=True)
        positive_count = sum(label for _, label in ranked)
        if positive_count == 0:
            continue
        values["Recall@1"].append(float(any(label for _, label in ranked[:1])))
        values["Recall@5"].append(float(any(label for _, label in ranked[:5])))
        values["Recall@10"].append(float(any(label for _, label in ranked[:10])))
        first = next(i + 1 for i, (_, label) in enumerate(ranked) if label)
        values["MRR"].append(1.0 / first)
        for k in (5, 10):
            dcg = sum(label / math.log2(i + 2) for i, (_, label) in enumerate(ranked[:k]))
            ideal = sum(1.0 / math.log2(i + 2) for i in range(min(k, positive_count)))
            values[f"NDCG@{k}"].append(dcg / ideal if ideal else 0.0)
    return {key: float(np.mean(value)) if value else 0.0 for key, value in values.items()} | {"queries": len(groups)}


def mean_pooling(model_output, attention_mask: torch.Tensor) -> torch.Tensor:
    token_embeddings = model_output.last_hidden_state
    mask = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return (token_embeddings * mask).sum(1) / torch.clamp(mask.sum(1), min=1e-9)


def encode(texts: list[str], prefix: str, tokenizer, model, device: torch.device, batch_size: int, max_length: int) -> np.ndarray:
    result: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(texts), batch_size):
            batch = [prefix + text for text in texts[start : start + batch_size]]
            encoded = tokenizer(batch, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
            encoded = {key: value.to(device) for key, value in encoded.items()}
            pooled = mean_pooling(model(**encoded), encoded["attention_mask"])
            pooled = torch.nn.functional.normalize(pooled, p=2, dim=1)
            result.append(pooled.cpu().numpy().astype(np.float32))
    return np.concatenate(result, axis=0) if result else np.empty((0, 0), dtype=np.float32)


def make_pairwise(rows: list[dict], features: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    groups = grouped(rows)
    deltas, labels = [], []
    for indices in groups.values():
        positives = [i for i in indices if rows[i]["label"] == 1]
        negatives = [i for i in indices if rows[i]["label"] == 0]
        for pos in positives:
            for neg in negatives:
                delta = features[pos] - features[neg]
                deltas.extend((delta, -delta))
                labels.extend((1, 0))
    return np.asarray(deltas, dtype=np.float32), np.asarray(labels, dtype=np.int8)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--feature-dir", type=Path, default=DEFAULT_FEATURE_DIR)
    parser.add_argument("--e5-model", default=DEFAULT_E5_MODEL)
    parser.add_argument("--output-dir", type=Path, default=Path("runs/rank_hybrid_v1"))
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--max-length", type=int, default=256)
    parser.add_argument("--seed", type=int, required=True, help="Random seed for reproducibility")
    parser.add_argument("--overwrite", action="store_true", help="Allow overwriting existing output directory")
    args = parser.parse_args()
    
    # Prepare output directory with atomic isolation
    overwrite_audit = prepare_output_directory(args.output_dir, args.overwrite)
    
    # Set random seeds
    set_seed(args.seed)
    
    run_id = str(uuid.uuid4())
    started = time.time()

    train_all = read_jsonl(args.feature_dir / "rerank_train_pairs.jsonl")
    val_all = read_jsonl(args.feature_dir / "rerank_validation_pairs.jsonl")
    train_extra_all = np.load(args.feature_dir / "rerank_train_extra.npy")
    val_extra_all = np.load(args.feature_dir / "rerank_validation_extra.npy")
    train_rows = public_rows(train_all)
    val_rows = public_rows(val_all)
    train_ix = [i for i, row in enumerate(train_all) if row in train_rows]
    val_ix = [i for i, row in enumerate(val_all) if row in val_rows]
    train_extra = train_extra_all[train_ix]
    val_extra = val_extra_all[val_ix]

    device = torch.device("cpu")
    tokenizer = AutoTokenizer.from_pretrained(args.e5_model)
    model = AutoModel.from_pretrained(args.e5_model).to(device)
    
    train_query_texts = [row["query"] for row in train_rows]
    train_memory_texts = [row["memory"] for row in train_rows]
    val_query_texts = [row["query"] for row in val_rows]
    val_memory_texts = [row["memory"] for row in val_rows]
    
    print("Encoding training queries and memories...", flush=True)
    train_query_emb = encode(train_query_texts, "query: ", tokenizer, model, device, args.batch_size, args.max_length)
    train_memory_emb = encode(train_memory_texts, "passage: ", tokenizer, model, device, args.batch_size, args.max_length)
    train_e5_cosine = np.sum(train_query_emb * train_memory_emb, axis=1, keepdims=True)
    
    print("Encoding validation queries and memories...", flush=True)
    val_query_emb = encode(val_query_texts, "query: ", tokenizer, model, device, args.batch_size, args.max_length)
    val_memory_emb = encode(val_memory_texts, "passage: ", tokenizer, model, device, args.batch_size, args.max_length)
    val_e5_cosine = np.sum(val_query_emb * val_memory_emb, axis=1, keepdims=True)
    
    train_combined = np.concatenate([train_e5_cosine, train_extra], axis=1).astype(np.float32)
    val_combined = np.concatenate([val_e5_cosine, val_extra], axis=1).astype(np.float32)
    
    print("Training pairwise logistic ranker...", flush=True)
    pair_x, pair_y = make_pairwise(train_rows, train_combined)
    scaler = StandardScaler()
    pair_scaled = scaler.fit_transform(pair_x)
    ranker = LogisticRegression(C=1.0, max_iter=2000, solver="lbfgs", random_state=42)
    ranker.fit(pair_scaled, pair_y)
    
    train_scores = scaler.transform(train_combined) @ ranker.coef_[0]
    val_scores = scaler.transform(val_combined) @ ranker.coef_[0]
    
    elapsed = time.time() - started
    
    feature_names = ["e5_cosine"] + json.loads((args.feature_dir / "rerank_extra_features.json").read_text(encoding="utf-8"))
    
    # Collect dependency versions
    import sklearn
    import transformers
    dependencies = {
        "python": platform.python_version(),
        "numpy": np.__version__,
        "torch": torch.__version__,
        "sklearn": sklearn.__version__,
        "transformers": transformers.__version__,
        "joblib": joblib.__version__,
    }
    
    # Compute input file hashes and counts
    train_pairs_path = args.feature_dir / "rerank_train_pairs.jsonl"
    val_pairs_path = args.feature_dir / "rerank_validation_pairs.jsonl"
    
    input_hashes = {
        "train_pairs": compute_file_hash(train_pairs_path),
        "validation_pairs": compute_file_hash(val_pairs_path),
        "train_extra_features": compute_file_hash(args.feature_dir / "rerank_train_extra.npy"),
        "validation_extra_features": compute_file_hash(args.feature_dir / "rerank_validation_extra.npy"),
    }
    
    counts = {
        "train_rows": len(train_rows),
        "val_rows": len(val_rows),
        "train_queries": len(grouped(train_rows)),
        "val_queries": len(grouped(val_rows)),
        "train_pairs": len(pair_x),
    }
    
    # Build complete manifest with reproducibility metadata
    manifest = build_training_manifest(
        run_id=run_id,
        seed=args.seed,
        input_hashes=input_hashes,
        counts=counts,
        elapsed_seconds=elapsed,
        overwrite_audit=overwrite_audit,
    )
    
    # Add extended fields for this specific training run
    manifest.update({
        "command_args": {
            "feature_dir": str(args.feature_dir),
            "e5_model": args.e5_model,
            "output_dir": str(args.output_dir),
            "batch_size": args.batch_size,
            "max_length": args.max_length,
            "seed": args.seed,
            "overwrite": args.overwrite,
        },
        "git_sha": get_git_sha(),
        "python_version": platform.python_version(),
        "dependencies": dependencies,
        "input_files": {
            "train_pairs": {
                "path": str(train_pairs_path),
                "sha256": input_hashes["train_pairs"],
                "total_rows": len(train_all),
                "public_filtered_rows": len(train_rows),
            },
            "validation_pairs": {
                "path": str(val_pairs_path),
                "sha256": input_hashes["validation_pairs"],
                "total_rows": len(val_all),
                "public_filtered_rows": len(val_rows),
            },
            "train_extra_features": {
                "path": str(args.feature_dir / "rerank_train_extra.npy"),
                "sha256": input_hashes["train_extra_features"],
            },
            "validation_extra_features": {
                "path": str(args.feature_dir / "rerank_validation_extra.npy"),
                "sha256": input_hashes["validation_extra_features"],
            },
        },
        "feature_dim": train_combined.shape[1],
        "feature_names": feature_names,
    })
    
    # Build legacy report for backward compatibility
    report = {
        "model_id": "MNEMOSYNE-MNS-RANK-HYBRID-01",
        "components": {
            "semantic_encoder": args.e5_model,
            "semantic_mode": "frozen_cpu_inference",
            "structured_features": 12,
            "ranker": "logistic_pairwise",
        },
        "data_policy": "AlpsBench public train/validation only; private weak data excluded",
        "train_queries": len(grouped(train_rows)),
        "validation_queries": len(grouped(val_rows)),
        "train_pairs": int(len(pair_x)),
        "feature_dim": int(train_combined.shape[1]),
        "feature_names": feature_names,
        "train_metrics": ranking_metrics(train_rows, train_scores),
        "validation_metrics": ranking_metrics(val_rows, val_scores),
        "elapsed_seconds": round(elapsed, 3),
        "verification": {
            "grouped_pairwise_training": True,
            "public_only": True,
            "private_weak_data_used": False,
            "gpu_required": False,
        },
    }
    
    joblib.dump({
        "scaler": scaler,
        "ranker": ranker,
        "feature_names": feature_names,
        "e5_model": args.e5_model,
    }, args.output_dir / "hybrid_ranker.joblib")
    
    with (args.output_dir / "validation_predictions.jsonl").open("w", encoding="utf-8") as f:
        for row, score in zip(val_rows, val_scores):
            f.write(json.dumps({
                "pair_id": row["pair_id"],
                "query_id": row["pair_id"].rsplit("::", 1)[0],
                "memory_id": row.get("memory_id"),
                "label": row["label"],
                "hybrid_score": float(score),
            }, ensure_ascii=False, separators=(",", ":")) + "\n")
    
    # Write manifest
    (args.output_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    
    (args.output_dir / "hybrid_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
